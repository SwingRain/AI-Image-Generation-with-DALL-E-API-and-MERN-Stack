import Home from "./Home";
import CreatePost from "./CreatePost";

export {
    Home,
    CreatePost,
}